package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    private String TABLE_NAME = "user_table";
    private String TABLE_NAME1 = "transfers_table";
    public DatabaseHelper(@Nullable Context context) {
        super(context, "User.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME +" (PHONENUMBER INTEGER PRIMARY KEY ,NAME TEXT,BALANCE DECIMAL,EMAIL VARCHAR,ACCOUNT_NO VARCHAR,IFSC_CODE VARCHAR)");
        db.execSQL("create table " + TABLE_NAME1 +" (TRANSACTIONID INTEGER PRIMARY KEY AUTOINCREMENT,DATE TEXT,FROMNAME TEXT,TONAME TEXT,AMOUNT DECIMAL,STATUS TEXT)");
        db.execSQL("insert into user_table values(1234567890,'Nguyen Tung Lam',100000.00,'21lam.nt@vinuni.edu.vn','XXXXXXXXXXXX1310','V202100571')");
        db.execSQL("insert into user_table values(2345678901,'Nguyen Nhat Minh',100000.00,'21minh.nn@vinuni.edu.vn','XXXXXXXXXXXX2341','V202100523')");
        db.execSQL("insert into user_table values(3456789012,'Nguyen Xuan Thai Duong',100000.00,'21duong.nxt@vinuni.edu.vn','XXXXXXXXXXXX3412','V202100519')");
        db.execSQL("insert into user_table values(4567890123,'Nguyen Canh Huy',100000.00,'21huy.nc@vinuni.edu.vn','XXXXXXXXXXXX4123','V202100412')");
        db.execSQL("insert into user_table values(5678901234,'Vu Binh Minh',100000.00,'21minh.vb@vinuni.edu.vn','XXXXXXXXXXXX2345','V202100456')");
        db.execSQL("insert into user_table values(6789012345,'Nguyen Nhat Minh',100000.00,'21minh.nn2@vinuni.edu.vn','XXXXXXXXXXXX3452','V202100570')");
        db.execSQL("insert into user_table values(7890123456,'Shynggys Shynbolatov',100000.00,'21shynbolatov.s@vinuni.edu.vn','XXXXXXXXXXX4523','V202100389')");
        db.execSQL("insert into user_table values(8901234567,'Nguyen Xuan Hieu',100000.00,'21hieu.nx@vinuni.edu.vn','XXXXXXXXXXXX5234','V202100567')");
        db.execSQL("insert into user_table values(9012345678,'Le Minh Tri',100000.00,'21tri.lm@vinuni.edu.vn','XXXXXXXXXXXX3456','V202100867')");
        db.execSQL("insert into user_table values(1234567809,'Dang Ngo Phuc Khang',100000.00,'21khang.dnp@vinuni.edu.vn','XXXXXXXXXXXX4563','V202100211')");

    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME1);
        onCreate(db);
    }

    public Cursor readalldata(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from user_table", null);
        return cursor;
    }

    public Cursor readparticulardata(String phonenumber){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from user_table where phonenumber = " +phonenumber, null);
        return cursor;
    }

    public Cursor readselectuserdata(String phonenumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from user_table except select * from user_table where phonenumber = " +phonenumber, null);
        return cursor;
    }

    public void updateAmount(String phonenumber, String amount){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("update user_table set balance = " + amount + " where phonenumber = " +phonenumber);
    }

    public Cursor readtransferdata(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from transfers_table", null);
        return cursor;
    }

    public boolean insertTransferData(String date,String from_name, String to_name, String amount, String status){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("DATE", date);
        contentValues.put("FROMNAME", from_name);
        contentValues.put("TONAME", to_name);
        contentValues.put("AMOUNT", amount);
        contentValues.put("STATUS", status);
        Long result = db.insert(TABLE_NAME1, null, contentValues);
        if(result == -1){
            return false;
        }else{
            return true;
        }
    }
}